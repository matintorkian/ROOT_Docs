# Auto generated configuration file
# using: 
# Revision: 1.19 
# Source: /local/reps/CMSSW/CMSSW/Configuration/Applications/python/ConfigBuilder.py,v 
# with command line options: Configuration/GenProduction/python/Gjet700ToInf.py --python_filename testMultipleA_cfg.py --eventcontent RAWSIM,LHE --customise Configuration/DataProcessing/Utils.addMonitoring --datatier GEN,LHE --fileout Output.root --conditions 110X_mcRun4_realistic_v3 --beamspot HLLHC14TeV --customise_commands process.source.numberEventsInLuminosityBlock=cms.untracked.uint32(100) --step LHE,GEN --geometry Extended2026D49 --era Phase2C9 --no_exec --mc -n 10
import FWCore.ParameterSet.Config as cms

from Configuration.Eras.Era_Phase2C9_cff import Phase2C9
import FWCore.ParameterSet.VarParsing as VarParsing

options = VarParsing.VarParsing ('analysis')
options.inputFiles = []
options.maxEvents = 10000
options.register ('gridpack',
                  '', # default value
                  VarParsing.VarParsing.multiplicity.singleton, # singleton or list
                  VarParsing.VarParsing.varType.string,          # string, int, or float
                  "/afs/cern.ch/user/m/mhajimag/public/final/local/tarball/GJets1j_5f_NLO_FXFX_pT700ToInf_slc7_amd64_gcc700_CMSSW_10_6_19_tarball.tar.xz")

options.parseArguments()
if options.inputFiles == [] and options.gridpack == '':
        print( 'you should either specify inputFiles or the gridpack' )
        raise Exception('you should either specify inputFiles or the gridpack' )

process = cms.Process('GEN2' if options.inputFiles else 'GEN',Phase2C9)

# import of standard configurations
process.load('Configuration.StandardSequences.Services_cff')
process.load('SimGeneral.HepPDTESSource.pythiapdt_cfi')
process.load('FWCore.MessageService.MessageLogger_cfi')
process.load('Configuration.EventContent.EventContent_cff')
process.load('SimGeneral.MixingModule.mixNoPU_cfi')
process.load('Configuration.Geometry.GeometryExtended2026D49Reco_cff')
process.load('Configuration.StandardSequences.MagneticField_cff')
process.load('Configuration.StandardSequences.Generator_cff')
process.load('IOMC.EventVertexGenerators.VtxSmearedHLLHC14TeV_cfi')
process.load('GeneratorInterface.Core.genFilterSummary_cff')
process.load('Configuration.StandardSequences.EndOfProcess_cff')
process.load('Configuration.StandardSequences.FrontierConditions_GlobalTag_cff')

process.maxEvents = cms.untracked.PSet(
        input = cms.untracked.int32(options.maxEvents),
        output = cms.optional.untracked.allowed(cms.int32,cms.PSet)
)


process.options = cms.untracked.PSet(
    FailPath = cms.untracked.vstring(),
    IgnoreCompletely = cms.untracked.vstring(),
    Rethrow = cms.untracked.vstring(),
    SkipEvent = cms.untracked.vstring(),
    allowUnscheduled = cms.obsolete.untracked.bool,
    canDeleteEarly = cms.untracked.vstring(),
    emptyRunLumiMode = cms.obsolete.untracked.string,
    eventSetup = cms.untracked.PSet(
        forceNumberOfConcurrentIOVs = cms.untracked.PSet(

        ),
        numberOfConcurrentIOVs = cms.untracked.uint32(1)
    ),
    fileMode = cms.untracked.string('FULLMERGE'),
    forceEventSetupCacheClearOnNewRun = cms.untracked.bool(False),
    makeTriggerResults = cms.obsolete.untracked.bool,
    numberOfConcurrentLuminosityBlocks = cms.untracked.uint32(1),
    numberOfConcurrentRuns = cms.untracked.uint32(1),
    numberOfStreams = cms.untracked.uint32(0),
    numberOfThreads = cms.untracked.uint32(1),
    printDependencies = cms.untracked.bool(False),
    sizeOfStackForThreadsInKB = cms.optional.untracked.uint32,
    throwIfIllegalParameter = cms.untracked.bool(True),
    wantSummary = cms.untracked.bool(False)
)

# Production Info
# process.configurationMetadata = cms.untracked.PSet(
#     annotation = cms.untracked.string('Configuration/GenProduction/python/Gjet700ToInf.py nevts:10'),
#     name = cms.untracked.string('Applications'),
#     version = cms.untracked.string('$Revision: 1.19 $')
# )

# Output definition

process.RAWSIMoutput = cms.OutputModule("PoolOutputModule",
    SelectEvents = cms.untracked.PSet(
        SelectEvents = cms.vstring('generation_step')
    ),
    compressionAlgorithm = cms.untracked.string('LZMA'),
    compressionLevel = cms.untracked.int32(1),
    dataset = cms.untracked.PSet(
        dataTier = cms.untracked.string('GEN'),
        filterName = cms.untracked.string('')
    ),
    eventAutoFlushCompressedSize = cms.untracked.int32(20971520),
    fileName = cms.untracked.string(options.outputFile),
    outputCommands = process.RAWSIMEventContent.outputCommands,
    splitLevel = cms.untracked.int32(0)
)

# Additional output definition

# Other statements
process.genstepfilter.triggerConditions=cms.vstring("generation_step")
from Configuration.AlCa.GlobalTag import GlobalTag
process.GlobalTag = GlobalTag(process.GlobalTag, '110X_mcRun4_realistic_v3', '')

process.genParticles = cms.EDProducer("GenParticleProducer",
    abortOnUnknownPDGCode = cms.untracked.bool(False),
    saveBarCodes = cms.untracked.bool(True),
    src = cms.InputTag("generatorSmeared")
)


process.generator = cms.EDFilter("Pythia8HadronizerFilter",
    PythiaParameters = cms.PSet(
        parameterSets = cms.vstring(
            'pythia8CommonSettings', 
            'pythia8CP5Settings', 
            'pythia8aMCatNLOSettings', 
            'processParameters'
        ),
        processParameters = cms.vstring('TimeShower:nPartonsInBorn = 1'),
        pythia8CP5Settings = cms.vstring(
            'Tune:pp 14', 
            'Tune:ee 7', 
            'MultipartonInteractions:ecmPow=0.03344', 
            'MultipartonInteractions:bProfile=2', 
            'MultipartonInteractions:pT0Ref=1.41', 
            'MultipartonInteractions:coreRadius=0.7634', 
            'MultipartonInteractions:coreFraction=0.63', 
            'ColourReconnection:range=5.176', 
            'SigmaTotal:zeroAXB=off', 
            'SpaceShower:alphaSorder=2', 
            'SpaceShower:alphaSvalue=0.118', 
            'SigmaProcess:alphaSvalue=0.118', 
            'SigmaProcess:alphaSorder=2', 
            'MultipartonInteractions:alphaSvalue=0.118', 
            'MultipartonInteractions:alphaSorder=2', 
            'TimeShower:alphaSorder=2', 
            'TimeShower:alphaSvalue=0.118', 
            'SigmaTotal:mode = 0', 
            'SigmaTotal:sigmaEl = 21.89', 
            'SigmaTotal:sigmaTot = 100.309', 
            'PDF:pSet=LHAPDF6:NNPDF31_nnlo_as_0118'
        ),
        pythia8CommonSettings = cms.vstring(
            'Tune:preferLHAPDF = 2', 
            'Main:timesAllowErrors = 10000', 
            'Check:epTolErr = 0.01', 
            'Beams:setProductionScalesFromLHEF = off', 
            'SLHA:keepSM = on', 
            'SLHA:minMassSM = 1000.', 
            'ParticleDecays:limitTau0 = on', 
            'ParticleDecays:tau0Max = 10', 
            'ParticleDecays:allowPhotonRadiation = on'
        ),
        pythia8aMCatNLOSettings = cms.vstring(
            'SpaceShower:pTmaxMatch = 1', 
            'SpaceShower:pTmaxFudge = 1', 
            'SpaceShower:MEcorrections = off', 
            'TimeShower:pTmaxMatch = 1', 
            'TimeShower:pTmaxFudge = 1', 
            'TimeShower:MEcorrections = off', 
            'TimeShower:globalRecoil = on', 
            'TimeShower:limitPTmaxGlobal = on', 
            'TimeShower:nMaxGlobalRecoil = 1', 
            'TimeShower:globalRecoilMode = 2', 
            'TimeShower:nMaxGlobalBranch = 1', 
            'TimeShower:weightGluonToQuark = 1'
        )
    ),
    comEnergy = cms.double(14000.0),
    filterEfficiency = cms.untracked.double(1.0),
    maxEventsToPrint = cms.untracked.int32(1),
    pythiaHepMCVerbosity = cms.untracked.bool(False),
    pythiaPylistVerbosity = cms.untracked.int32(1)
)


process.ak4GenJetsNoNu = cms.EDProducer("FastjetJetProducer",
    Active_Area_Repeats = cms.int32(5),
    GhostArea = cms.double(0.01),
    Ghost_EtaMax = cms.double(6.0),
    Rho_EtaMax = cms.double(4.5),
    doAreaFastjet = cms.bool(False),
    doPUOffsetCorr = cms.bool(False),
    doPVCorrection = cms.bool(False),
    doRhoFastjet = cms.bool(False),
    inputEMin = cms.double(0.0),
    inputEtMin = cms.double(0.0),
    jetAlgorithm = cms.string('AntiKt'),
    jetPtMin = cms.double(3.0),
    jetType = cms.string('GenJet'),
    maxBadEcalCells = cms.uint32(9999999),
    maxBadHcalCells = cms.uint32(9999999),
    maxProblematicEcalCells = cms.uint32(9999999),
    maxProblematicHcalCells = cms.uint32(9999999),
    maxRecoveredEcalCells = cms.uint32(9999999),
    maxRecoveredHcalCells = cms.uint32(9999999),
    minSeed = cms.uint32(14327),
    nSigmaPU = cms.double(1.0),
    rParam = cms.double(0.4),
    radiusPU = cms.double(0.5),
    src = cms.InputTag("genParticlesForJetsNoNu"),
    srcPVs = cms.InputTag(""),
    useDeterministicSeed = cms.bool(True)
)


process.vbfGenJetFilterD = cms.EDAnalyzer("VBFGenJetAnalyzer",
    GenJetCollection = cms.InputTag("ak4GenJetsNoNu"),
    deltaRNoLep = cms.untracked.double(0.3),
    genParticles = cms.InputTag("genParticles"),
    leadJetsNoLepMass = cms.untracked.bool(True)
)


process.vbfGenJetFilterB = cms.EDAnalyzer("VBFGenJetAnalyzer",
    GenJetCollection = cms.InputTag("ak4GenJetsNoNu"),
    maxDeltaEta = cms.untracked.double(99999.0),
    maxDeltaPhi = cms.untracked.double(3.2),
    maxEta = cms.untracked.double(4.8),
    minDeltaEta = cms.untracked.double(3.0),
    minDeltaPhi = cms.untracked.double(2.15),
    minEta = cms.untracked.double(-4.8),
    minPt = cms.untracked.double(40),
    oppositeHemisphere = cms.untracked.bool(False)
)


process.vbfGenJetFilterC = cms.EDAnalyzer("VBFGenJetAnalyzer",
    GenJetCollection = cms.InputTag("ak4GenJetsNoNu"),
    maxDeltaEta = cms.untracked.double(99999.0),
    maxDeltaPhi = cms.untracked.double(3.2),
    maxEta = cms.untracked.double(4.8),
    minDeltaEta = cms.untracked.double(3.0),
    minDeltaPhi = cms.untracked.double(-1.0),
    minEta = cms.untracked.double(-4.8),
    minPt = cms.untracked.double(40),
    oppositeHemisphere = cms.untracked.bool(False)
)


process.vbfGenJetFilterA = cms.EDAnalyzer("VBFGenJetAnalyzer",
    GenJetCollection = cms.InputTag("ak4GenJetsNoNu"),
    maxDeltaEta = cms.untracked.double(99999.0),
    maxDeltaPhi = cms.untracked.double(2.15),
    maxEta = cms.untracked.double(4.8),
    minDeltaEta = cms.untracked.double(3.0),
    minDeltaPhi = cms.untracked.double(-1.0),
    minEta = cms.untracked.double(-4.8),
    minPt = cms.untracked.double(40),
    oppositeHemisphere = cms.untracked.bool(False)
)


process.genParticlesForJetsNoNu = cms.EDProducer("InputGenJetsParticleSelector",
    excludeFromResonancePids = cms.vuint32(12, 13, 14, 16),
    excludeResonances = cms.bool(False),
    ignoreParticleIDs = cms.vuint32(
        1000022, 1000012, 1000014, 1000016, 2000012, 
        2000014, 2000016, 1000039, 5100039, 4000012, 
        4000014, 4000016, 9900012, 9900014, 9900016, 
        39, 12, 14, 16
    ),
    partonicFinalState = cms.bool(False),
    src = cms.InputTag("genParticles"),
    tausAsJets = cms.bool(False)
)


if options.inputFiles:
        # Input source
        process.source = cms.Source ("PoolSource",
                                     fileNames=cms.untracked.vstring(['file:{0}'.format(a) for a in options.inputFiles])
                             )
else:
        process.source = cms.Source("EmptySource")
        process.externalLHEProducer = cms.EDProducer("ExternalLHEProducer",
                                                     args = cms.vstring(options.gridpack),
                                                     nEvents = cms.untracked.uint32(options.maxEvents),
                                                     numberOfParameters = cms.uint32(1),
                                                     outputFile = cms.string('cmsgrid_final.lhe'),
                                                     scriptName = cms.FileInPath('GeneratorInterface/LHEInterface/data/run_generic_tarball_cvmfs.sh')
                                             )
        process.LHEoutput = cms.OutputModule("PoolOutputModule",
                                             dataset = cms.untracked.PSet(
                                                     dataTier = cms.untracked.string('LHE'),
                                                     filterName = cms.untracked.string('')
                                             ),
                                             fileName = cms.untracked.string(options.outputFile.replace('.root' ,  '_inLHE.root') ),
                                             outputCommands = process.LHEEventContent.outputCommands,
                                             splitLevel = cms.untracked.int32(0)
                                     )

        process.lhe_step = cms.Path(process.externalLHEProducer)
        process.LHEoutput_step = cms.EndPath(process.LHEoutput)
        process.source.numberEventsInLuminosityBlock=cms.untracked.uint32(100)


process.ProductionFilterSequence = cms.Sequence(process.generator+cms.SequencePlaceholder("pgen")+process.genParticlesForJetsNoNu+process.ak4GenJetsNoNu)
process.SimFilterSequence = cms.Sequence(process.generator+process.genParticlesForJetsNoNu+process.ak4GenJetsNoNu+cms.SequencePlaceholder("psim"))
process.TFileService = cms.Service("TFileService", fileName = cms.string( options.outputFile.replace('.root' ,  '_histos.root') ) )
process.AnalysisSequence = cms.Sequence(process.vbfGenJetFilterA+process.vbfGenJetFilterB+process.vbfGenJetFilterC+process.vbfGenJetFilterD)

# Path and EndPath definitions

process.generation_step = cms.Path(process.pgen)
process.genfiltersummary_step = cms.EndPath(process.AnalysisSequence+process.genFilterSummary)
process.endjob_step = cms.EndPath(process.endOfProcess)
process.RAWSIMoutput_step = cms.EndPath(process.RAWSIMoutput)

# Schedule definition
if options.inputFiles:
        process.schedule = cms.Schedule(process.generation_step,process.genfiltersummary_step,process.endjob_step,process.RAWSIMoutput_step)
else:
        process.schedule = cms.Schedule(process.lhe_step,process.generation_step,process.genfiltersummary_step,process.endjob_step,process.RAWSIMoutput_step,process.LHEoutput_step)
from PhysicsTools.PatAlgos.tools.helpers import associatePatAlgosToolsTask
associatePatAlgosToolsTask(process)
# filter all path with the production filter sequence
for path in process.paths:
	if path in ['lhe_step']: continue
	getattr(process,path).insert(0, process.ProductionFilterSequence)

# customisation of the process.

# Automatic addition of the customisation function from Configuration.DataProcessing.Utils
from Configuration.DataProcessing.Utils import addMonitoring 

#call to customisation function addMonitoring imported from Configuration.DataProcessing.Utils
process = addMonitoring(process)

# End of customisation functions

# Customisation from command line

# Add early deletion of temporary data products to reduce peak memory need
from Configuration.StandardSequences.earlyDeleteSettings_cff import customiseEarlyDelete
process = customiseEarlyDelete(process)
# End adding early deletion
