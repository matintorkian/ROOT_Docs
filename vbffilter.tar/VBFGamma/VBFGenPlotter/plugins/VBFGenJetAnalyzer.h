#ifndef VBFGenJetAnalyzer_h
#define VBFGenJetAnalyzer_h

// CMSSW include files
#include "FWCore/Framework/interface/Frameworkfwd.h"
#include "FWCore/Framework/interface/EDAnalyzer.h"
#include "FWCore/Framework/interface/Event.h"
#include "FWCore/Framework/interface/MakerMacros.h"
#include "FWCore/ParameterSet/interface/ParameterSet.h"
#include "FWCore/ServiceRegistry/interface/Service.h"

#include "SimDataFormats/GeneratorProducts/interface/HepMCProduct.h"

#include "DataFormats/JetReco/interface/GenJetCollection.h"
#include "DataFormats/HepMCCandidate/interface/GenParticle.h"

// ROOT includes
#include "TFile.h"
#include "TH1D.h"

// C++ include files
#include <memory>
#include <map>


using namespace edm;
//
// class declaration
//

class VBFGenJetAnalyzer : public edm::EDAnalyzer {
public:
  explicit VBFGenJetAnalyzer(const edm::ParameterSet&);
  ~VBFGenJetAnalyzer() override;

  //void analyze(edm::Event&, const edm::EventSetup&) 
  void analyze(Event const&, EventSetup const&) override;
private:
  // ----------memeber function----------------------
  int charge(const int& Id);
  std::vector<HepMC::GenParticle*> getVisibleDecayProducts(HepMC::GenParticle* particle);
  std::vector<HepMC::GenParticle*> getNu(const HepMC::GenEvent* particles);
  std::vector<HepMC::GenParticle*> getSt3(const HepMC::GenEvent* particles);
  void printGenVector(std::vector<HepMC::GenParticle*> vec);
  double nuMET(std::vector<HepMC::GenParticle*> vNu);

  std::vector<const reco::GenJet*> filterGenJets(const std::vector<reco::GenJet>* jets);
  std::vector<const reco::GenParticle*> filterGenLeptons(const std::vector<reco::GenParticle>* particles);

  //**************************
  // Private Member data *****
private:
  // Dijet cut
  bool oppositeHemisphere;
  bool leadJetsNoLepMass;
  double ptMin;
  double etaMin;
  double etaMax;
  double minDeltaPhi;
  double maxDeltaPhi;
  double minDeltaEta;
  double maxDeltaEta;
  double deltaRJetLep;

  // Input tags
  edm::EDGetTokenT<reco::GenJetCollection> m_GenJetCollection;
  edm::EDGetTokenT<reco::GenParticleCollection> m_GenParticleCollection;

  //Histograms
  TH1F* h_Mass;
  TH1F* h_Errors;
};

#endif
